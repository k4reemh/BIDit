// src/messages.ts
var PORT_NAME = "bidit";

// src/config.ts
var HTTP = "https://bidit-backend-fekn.onrender.com".replace(/\/$/, "");
var BACKEND_WS = `${HTTP.replace(/^http/, "ws")}/ws`;
var WEB_ORIGIN = "https://www.biditsol.com".replace(/\/$/, "");

// src/popup.ts
var $ = (id) => document.getElementById(id);
var loginView = $("loginView");
var accountView = $("accountView");
var emailInput = $("email");
var passwordInput = $("password");
var loginError = $("loginError");
var dot = $("dot");
var connText = $("connText");
var settled = $("settled");
var verifyNotice = $("verifyNotice");
$("signupLink").href = `${WEB_ORIGIN}/?signup=1`;
$("forgotLink").href = `${WEB_ORIGIN}/?forgot=1`;
$("addFundsLink").href = `${WEB_ORIGIN}/deposit`;
$("verifyLink").href = `${WEB_ORIGIN}/?signin=1`;
var port = chrome.runtime.connect({ name: PORT_NAME });
port.onMessage.addListener((msg) => {
  if (msg.evt === "STATUS") {
    const loggedIn = msg.handle !== null;
    loginView.classList.toggle("hidden", loggedIn);
    accountView.classList.toggle("hidden", !loggedIn);
    dot.className = `dot ${msg.connected ? "on" : "off"}`;
    connText.textContent = loggedIn ? `${msg.handle} \xB7 ${msg.connected ? "connected" : "connecting\u2026"}` : "not signed in";
    verifyNotice.classList.toggle("hidden", !loggedIn || msg.emailVerified);
    if (loggedIn) loginError.classList.add("hidden");
  } else if (msg.evt === "AUTH_ERROR") {
    loginError.textContent = msg.message;
    loginError.classList.remove("hidden");
  } else if (msg.evt === "SERVER" && msg.message.type === "BALANCE_UPDATE") {
    settled.textContent = `$${msg.message.settled}`;
  }
});
function submitLogin() {
  const email = emailInput.value.trim();
  const password = passwordInput.value;
  if (!email || !password) return;
  loginError.classList.add("hidden");
  port.postMessage({ cmd: "EMAIL_LOGIN", email, password });
}
$("loginBtn").addEventListener("click", submitLogin);
passwordInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") submitLogin();
});
$("logoutBtn").addEventListener("click", () => {
  settled.textContent = "-";
  port.postMessage({ cmd: "LOGOUT" });
});
