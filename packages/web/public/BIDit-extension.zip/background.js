// src/config.ts
var HTTP = "https://bidit-backend-fekn.onrender.com".replace(/\/$/, "");
var BACKEND_HTTP = HTTP;
var BACKEND_WS = `${HTTP.replace(/^http/, "ws")}/ws`;
var WEB_ORIGIN = "https://www.biditsol.com".replace(/\/$/, "");

// src/messages.ts
var PORT_NAME = "bidit";

// src/background.ts
var ports = /* @__PURE__ */ new Set();
var subscribed = /* @__PURE__ */ new Set();
var token = null;
var handle = null;
var userId = null;
var emailVerified = true;
var ws = null;
var connected = false;
var lastBalance = null;
var reconnectTimer;
var ready = loadAuth();
async function loadAuth() {
  const got = await chrome.storage.local.get(["biditToken", "biditHandle", "biditUserId", "biditEmailVerified"]);
  token = got.biditToken ?? null;
  handle = got.biditHandle ?? null;
  userId = got.biditUserId ?? null;
  emailVerified = got.biditEmailVerified !== false;
}
function broadcast(msg) {
  for (const port of ports) {
    try {
      port.postMessage(msg);
    } catch {
    }
  }
}
var statusMsg = () => ({ evt: "STATUS", connected, handle, emailVerified: handle ? emailVerified : true });
var connecting = false;
var backoff = 0;
function sendWs(obj) {
  if (ws && ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(obj));
}
async function mintTicket() {
  if (!token) return null;
  try {
    const res = await fetch(`${BACKEND_HTTP}/realtime/ticket`, {
      method: "POST",
      headers: { "content-type": "application/json", authorization: `Bearer ${token}` },
      body: "{}"
    });
    if (res.status === 401 || res.status === 403) {
      handleSessionExpired();
      return null;
    }
    if (!res.ok) return null;
    const data = await res.json().catch(() => null);
    return typeof data?.ticket === "string" ? data.ticket : null;
  } catch {
    return null;
  }
}
async function connectWs() {
  if (!token || connecting) return;
  if (ws && (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING)) return;
  connecting = true;
  const ticket = await mintTicket();
  connecting = false;
  if (!ticket) {
    if (token) scheduleReconnect();
    return;
  }
  const sock = new WebSocket(`${BACKEND_WS}?ticket=${encodeURIComponent(ticket)}`);
  ws = sock;
  sock.addEventListener("open", () => {
    connected = true;
    backoff = 0;
    broadcast(statusMsg());
    for (const room of subscribed) sendWs({ type: "SUBSCRIBE", room });
  });
  sock.addEventListener("message", (ev) => {
    let message;
    try {
      message = JSON.parse(String(ev.data));
    } catch {
      return;
    }
    if (message.type === "BALANCE_UPDATE") lastBalance = message;
    broadcast({ evt: "SERVER", message });
  });
  sock.addEventListener("close", (ev) => {
    connected = false;
    if (ws === sock) ws = null;
    broadcast(statusMsg());
    if (ev.code === 4001) handleSessionExpired();
    else if (token) scheduleReconnect();
  });
  sock.addEventListener("error", () => {
    try {
      sock.close();
    } catch {
    }
  });
}
function scheduleReconnect() {
  if (reconnectTimer || !token) return;
  const delay = Math.min(15e3, 1500 * Math.pow(1.7, backoff));
  backoff = Math.min(backoff + 1, 6);
  reconnectTimer = setTimeout(() => {
    reconnectTimer = void 0;
    void connectWs();
  }, delay);
}
function closeWs() {
  if (ws) {
    try {
      ws.close();
    } catch {
    }
    ws = null;
  }
  connected = false;
}
function handleSessionExpired() {
  const wasSignedIn = token !== null;
  token = null;
  handle = null;
  userId = null;
  lastBalance = null;
  subscribed.clear();
  if (reconnectTimer) {
    clearTimeout(reconnectTimer);
    reconnectTimer = void 0;
  }
  void chrome.storage.local.remove(["biditToken", "biditHandle", "biditUserId"]);
  closeWs();
  if (wasSignedIn) broadcast({ evt: "AUTH_ERROR", message: "Your session expired. Please sign in again." });
  broadcast(statusMsg());
}
function ensureSubscribed(room) {
  subscribed.add(room);
  if (ws && ws.readyState === WebSocket.OPEN) sendWs({ type: "SUBSCRIBE", room });
  else void connectWs();
}
function resync() {
  if (ws && ws.readyState === WebSocket.OPEN) {
    for (const room of subscribed) sendWs({ type: "SUBSCRIBE", room });
  } else if (token) {
    void connectWs();
  }
}
setInterval(resync, 12e3);
async function resolveCoin(coin) {
  try {
    const res = await fetch(`${BACKEND_HTTP}/resolve?coin=${encodeURIComponent(coin)}`);
    return res.ok ? res.json() : null;
  } catch {
    return null;
  }
}
async function handleHello(coin) {
  const resolved = await resolveCoin(coin);
  if (!resolved) {
    broadcast({ evt: "ROOM", coin, room: null });
    return;
  }
  broadcast({ evt: "ROOM", coin, room: resolved.room, sellerHandle: resolved.sellerHandle });
  ensureSubscribed(resolved.room);
}
async function handleEmailLogin(email, password) {
  let res;
  try {
    res = await fetch(`${BACKEND_HTTP}/auth/login`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ email, password })
    });
  } catch {
    broadcast({ evt: "AUTH_ERROR", message: "Can\u2019t reach BIDit right now. Check your connection." });
    return;
  }
  const data = await res.json().catch(() => null);
  if (!res.ok || !data?.token) {
    const msg = res.status === 429 ? "Too many attempts. Wait a minute and try again." : res.status === 403 ? data?.error ?? "This account isn\u2019t available." : data?.error ?? "Wrong email or password.";
    broadcast({ evt: "AUTH_ERROR", message: msg });
    return;
  }
  token = data.token;
  handle = data.handle ?? null;
  userId = data.userId ?? null;
  emailVerified = data.emailVerified !== false;
  backoff = 0;
  await chrome.storage.local.set({
    biditToken: token,
    biditHandle: handle,
    biditUserId: userId,
    biditEmailVerified: emailVerified
  });
  closeWs();
  void connectWs();
  broadcast(statusMsg());
}
async function handleSetSession(t, h, uid) {
  token = t;
  handle = h;
  userId = uid;
  emailVerified = true;
  backoff = 0;
  await chrome.storage.local.set({
    biditToken: token,
    biditHandle: handle,
    biditUserId: userId,
    biditEmailVerified: true
  });
  closeWs();
  void connectWs();
  broadcast(statusMsg());
}
async function handleLogout() {
  token = null;
  handle = null;
  userId = null;
  emailVerified = true;
  lastBalance = null;
  backoff = 0;
  await chrome.storage.local.remove(["biditToken", "biditHandle", "biditUserId", "biditEmailVerified"]);
  subscribed.clear();
  closeWs();
  broadcast(statusMsg());
}
async function handleUi(msg, port) {
  await ready;
  switch (msg.cmd) {
    case "HELLO":
      await handleHello(msg.coin);
      break;
    case "BID":
      sendWs({ type: "BID_INTENT", auctionId: msg.auctionId, amount: msg.amount, clientNonce: msg.nonce });
      break;
    case "GIVEAWAY_ENTER":
      sendWs({ type: "GIVEAWAY_ENTER", giveawayId: msg.giveawayId });
      break;
    case "EMAIL_LOGIN":
      await handleEmailLogin(msg.email, msg.password);
      break;
    case "SET_SESSION":
      await handleSetSession(msg.token, msg.handle, msg.userId);
      break;
    case "LOGOUT":
      await handleLogout();
      break;
    case "PING":
      resync();
      port.postMessage({ evt: "PONG" });
      break;
  }
}
chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== PORT_NAME) return;
  ports.add(port);
  void ready.then(() => {
    port.postMessage(statusMsg());
    if (lastBalance) port.postMessage({ evt: "SERVER", message: lastBalance });
    if (token && !connected) void connectWs();
  });
  port.onMessage.addListener((m) => void handleUi(m, port));
  port.onDisconnect.addListener(() => ports.delete(port));
});
